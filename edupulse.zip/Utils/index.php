<?php 

include "Util.php";
Util::redirect("../404.php", "error", "404");
 ?>
<?php 

define("SITE_NAME", "EduPulse");
 ?>